import PageTemplate, { generateMetadata } from './(pages)/[slug]/page'

export default PageTemplate

export { generateMetadata }
